# Monitor system

monitor system

## build
```shell
pnpm init

pnpm i -r

pnpm build

pnpm add esbuild -D
```

## gitee token
86379f56ee9eb073635ddcf31ff70dec



