const express = require('express');
const bodyParser = require('body-parser');

const app = express();

app.use(bodyParser.json());

app.use(express.static('public'));  

app.post('/api/data', (req, res) => {
    const data = req.body;
    console.log(`data is ${JSON.stringify(data)}`);

    res.send('Data received');
});

// 启动服务器并监听端口  
const port = 3000;
app.listen(port, () => {
    console.log(`Server started on port ${port}`);
});