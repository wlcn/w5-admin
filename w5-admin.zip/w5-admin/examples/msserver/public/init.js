const app = new BrowserApp();
app.init({
    app: 'cc-admin',
    env: 'dev',
    dsn: 'http://localhost:3000/api/data',
    enableConsole: true,
    enableError: true,
    enableDom: true,
    enableFetch: true,
    enableXhr: true,
    enableHashRoute: true,
    enableHistoryRoute: true,
    enablePromise: true,
    throttleDelayTime: 500,
    ignoreUrls: [],
    reportResponds: false,
    backTrackerId() {
        return '12345';
    }
});
app.start();

