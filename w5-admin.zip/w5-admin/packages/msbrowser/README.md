# browser package

```shell
pnpm add esbuild -D

pnpm build

pnpm package
```