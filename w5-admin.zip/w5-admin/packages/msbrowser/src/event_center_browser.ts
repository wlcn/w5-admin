import { EventData, EventCenter } from 'mscore';


export class EventCenterBrowser extends EventCenter {

    private static _instance: EventCenterBrowser | null = null;

    public static getInstance(): EventCenterBrowser {
        if (EventCenterBrowser._instance === null) {
            EventCenterBrowser._instance = new EventCenterBrowser();
        }
        return EventCenterBrowser._instance!;
    }

    private listener: any = {

    }

    on(eventName: string, callback: any): void {
        if (!this.listener[eventName]) {
            this.listener[eventName] = [];
        }
        this.listener[eventName].push(callback);
    }

    off(eventName: string, callback: any): void {
        if (!this.listener[eventName]) {
            return;
        }
        const index = this.listener[eventName].indexOf(callback);
        if (index !== -1) {
            this.listener[eventName].splice(index, 1);
        }
    }

    dispatch(eventName: string, data: any): void {
        if (!this.listener[eventName]) {
            return;
        }
        const eventData = new EventData(eventName, data);
        this.listener[eventName].forEach((callback: any) => {
            callback(eventData);
        });
    }
}

