import { Consumer } from "mscore";
import { getLocationHref, getTimestamp, unknownToString } from "./common";
import { EventCenterBrowser } from "./event_center_browser";
import { BrowserEventTypes } from "./app_browser";

export class ConsumerPromise extends Consumer {
    enable(): boolean {
        return true;
    }
    init(): void {
        EventCenterBrowser.getInstance().on(BrowserEventTypes.UNHANDLEDREJECTION, (event: any) => {
            this.consume(event);
        });
    }
    consume(event: any): void {
        const key = event.eventName + getTimestamp();
        const data: any = {
            message: unknownToString(event.data.reason),
            url: getLocationHref(),
            name: event.data.type,
            time: event.data.timeStamp
        }
        localStorage.setItem(key, JSON.stringify(data));
    }

}

