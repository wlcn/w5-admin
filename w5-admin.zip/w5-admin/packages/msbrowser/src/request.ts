import { IAnyObject, MethodTypes, getTrackerId, obj2query } from "./common";


export function beacon(url: string, data: IAnyObject): boolean {
  const trackerId = getTrackerId();
  data.trackerId = trackerId;
  return navigator.sendBeacon(url, JSON.stringify(data));
}


export function get(url: string, data: IAnyObject): Promise<any> {
  const trackerId = getTrackerId();
  data.trackerId = trackerId;
  return xhr(MethodTypes.GET, `${url}${url.indexOf('?') === -1 ? '?' : ''}${obj2query(data)}`, '');
}


export function post(url: string, data: IAnyObject): Promise<any> {
  const trackerId = getTrackerId();
  data.trackerId = trackerId;
  return xhr(MethodTypes.POST, url, data);
}


export function xhr(method: MethodTypes, url: string, data: any): Promise<any> {
  return new Promise((rs, rj) => {
    try {
      const xhr = new XMLHttpRequest();
      xhr.open(method, url);
      xhr.setRequestHeader('Content-Type', 'application/json;charset=UTF-8');
      if (method === MethodTypes.POST) {
        xhr.send(JSON.stringify(data));
      } else {
        xhr.send();
      }
      xhr.onreadystatechange = () => {
        if (xhr.readyState == XMLHttpRequest.DONE && xhr.status == 200) {
          rs(JSON.parse(xhr.response));
        } else {
          new Error(xhr.response);
        }
      };
    } catch (error) {
      rj(error);
    }
  });
}

export function imgRequest(url: string, data: IAnyObject): void {
  let img = new Image();
  const spliceStr = url.indexOf('?') === -1 ? '?' : '&';
  img.src = `${url}${spliceStr}data=${encodeURIComponent(JSON.stringify(data))}`;
  img = null as any;
}
