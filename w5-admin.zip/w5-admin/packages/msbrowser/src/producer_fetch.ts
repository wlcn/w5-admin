import { Producer } from "mscore";
import { HttpCollectedType, replaceOld, voidFun, HttpTypes, getUrlPath } from "./common";
import { EventCenterBrowser } from "./event_center_browser";
import { BrowserEventTypes, global } from "./app_browser";


export class ProducerFetch extends Producer {
    enable(): boolean {
        return true;
    }
    init(): void {
        const _self = this;
        monitorFetch.call(this, _self.produce);
        console.info(`producer fetch init done`);
    }
    produce(args: any): void {
        EventCenterBrowser.getInstance().dispatch(BrowserEventTypes.FETCH, args);
        return args;
    }

}

function monitorFetch(this: any, notify: (data: any) => void) {
    if (!('fetch' in global)) {
        return
    }
    const { dsn, ignoreUrls = [], reportResponds = false } = global.browserOptions;
    const ignore = [...ignoreUrls, dsn].map((url) => getUrlPath(url));
    replaceOld(global, HttpTypes.FETCH, (originalFetch: voidFun) => {
        return function (url: string, config: Partial<Request> = {}): void {
            const sTime = Date.now();
            const method = (config && config.method) || 'GET'
            const httpCollect: HttpCollectedType = {
                request: {
                    url,
                    method,
                    data: config && config.body
                },
                time: sTime,
                response: {}
            };
            const headers = new Headers(config.headers || {});
            Object.assign(headers, {
                setRequestHeader: headers.set
            });
            config = {
                ...config,
                headers
            };
            const isBlock = ignore.includes(getUrlPath(url));
            return originalFetch.apply(global, [url, config]).then(
                (res: Response) => {
                    const resClone = res.clone();
                    const eTime = Date.now();
                    httpCollect.elapsedTime = eTime - sTime;
                    httpCollect.response.status = resClone.status;
                    resClone.text().then((data) => {
                        if (isBlock) return;
                        if (reportResponds) {
                            httpCollect.response.data = data;
                        }
                        notify(httpCollect);
                    });
                    return res;
                },
                (err: Error) => {
                    if (isBlock) return;
                    const eTime = Date.now();
                    httpCollect.elapsedTime = eTime - sTime;
                    httpCollect.response.status = 0;
                    notify(httpCollect);
                    throw err;
                }
            );
        };
    });
}




