import { Producer } from "mscore";
import { throttle, on } from "./common";
import { EventCenterBrowser } from "./event_center_browser";
import { BrowserBreadcrumbTypes, BrowserEventTypes, global } from "./app_browser";


export class ProducerDom extends Producer {
    enable(): boolean {
        return true;
    }
    init(): void {
        const _self = this;
        const { throttleDelayTime } = global.browserOptions;
        const clickThrottle = throttle(_self.produce, throttleDelayTime)
        on(
            global.document,
            'click',
            function () {
                clickThrottle({
                    category: BrowserBreadcrumbTypes.CLICK,
                    data: this
                })
            },
            true
        );
        console.info(`producer dom init done`);
    }
    produce(args: any): void {
        const { category, data } = args;
        const htmlString = htmlElementAsString(data.activeElement as HTMLElement);
        EventCenterBrowser.getInstance().dispatch(BrowserEventTypes.DOM, { category, htmlString });
        return args;
    }

}


export function htmlElementAsString(target: HTMLElement): string {
    if (!target) {
        return '';
    }
    const tagName = target.tagName.toLowerCase();
    if (tagName === 'body') {
        return '';
    }
    let classNames = target.classList.value;
    classNames = classNames !== '' ? ` class="${classNames}"` : '';
    const id = target.id ? ` id="${target.id}"` : '';
    const innerText = target.innerText;
    return `<${tagName}${id}${classNames !== '' ? classNames : ''}>${innerText}</${tagName}>`;
}


