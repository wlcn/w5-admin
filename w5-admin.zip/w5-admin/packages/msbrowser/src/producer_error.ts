import { Producer } from "mscore";
import { on } from "./common";
import { EventCenterBrowser } from "./event_center_browser";
import { BrowserEventTypes, global } from "./app_browser";


export class ProducerError extends Producer {
    enable(): boolean {
        return true;
    }
    init(): void {
        const _self = this;
        on(
            global,
            'error',
            function (e: ErrorEvent) {
                _self.produce(e);
            },
            true
        );
        console.info(`producer error init done`);
    }
    produce(args: any): void {
        EventCenterBrowser.getInstance().dispatch(BrowserEventTypes.ERROR, args);
        return args;
    }

}


