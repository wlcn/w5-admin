import { BrowserReportType, getTimestamp, report } from "./common";
import { EventCenterBrowser } from "./event_center_browser";
import { BrowserEventTypes, global } from "./app_browser";
import { Consumer } from "mscore";

export class ConsumerDom extends Consumer {
    enable(): boolean {
        return true;
    }
    init(): void {
        EventCenterBrowser.getInstance().on(BrowserEventTypes.DOM, (event: any) => {
            this.consume(event);
        });
    }
    consume(event: any): void {
        const key = event.eventName + getTimestamp();
        localStorage.setItem(key, JSON.stringify(event.data));
        const { dsn } = global.browserOptions;
        report(dsn, event.data, BrowserReportType.IMG);
    }

}