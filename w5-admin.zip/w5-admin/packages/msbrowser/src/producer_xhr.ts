import { Producer } from "mscore";
import { replaceOld, voidFun, getUrlPath, IAnyObject, getTimestamp } from "./common";
import { EventCenterBrowser } from "./event_center_browser";
import { BrowserEventTypes, global } from "./app_browser";


export class ProducerXhr extends Producer {
    enable(): boolean {
        return true;
    }
    init(): void {
        const _self = this;
        monitorXhr.call(this, _self.produce);
        console.info(`producer XHR init done`);
    }
    produce(args: any): void {
        EventCenterBrowser.getInstance().dispatch(BrowserEventTypes.XHR, args);
        return args;
    }

}


function monitorXhr(this: any, notify: (data: any) => void) {
    if (!('XMLHttpRequest' in global)) {
        return
    }
    const originalXhrProto = XMLHttpRequest.prototype;

    const { dsn, ignoreUrls = [], reportResponds = false } = global.browserOptions;
    const ignore = [...ignoreUrls, dsn].map((url) => getUrlPath(url));
    replaceOld(originalXhrProto, 'open', (originalOpen: voidFun): voidFun => {
        return function (this: any, ...args: any[]): void {
            this.httpCollect = {
                request: {
                    method: args[0] ? args[0].toUpperCase() : args[0],
                    url: args[1]
                },
                response: {},
                time: getTimestamp()
            };
            originalOpen.apply(this, args);
        };
    });
    replaceOld(originalXhrProto, 'send', (originalSend: voidFun): voidFun => {
        return function (this: IAnyObject, ...args: any[]): void {
            const { request } = this.httpCollect;
            const { url } = request;
            this.addEventListener('loadend', function (this: any) {
                const isBlock = ignore.includes(getUrlPath(url));
                if (isBlock) return;
                const { responseType, response, status } = this;
                request.data = args[0];
                const eTime = getTimestamp();
                if (reportResponds && ['', 'json', 'text'].indexOf(responseType) !== -1) {
                    this.httpCollect.response.data = typeof response === 'object' ? JSON.stringify(response) : response;
                }
                this.httpCollect.response.status = status;
                this.httpCollect.elapsedTime = eTime - this.httpCollect.time;
                notify(this.httpCollect);
            });
            originalSend.apply(this, args);
        };
    });
}


