import { Producer } from "mscore";
import { getLocationHref, replaceOld, voidFun } from "./common";
import { EventCenterBrowser } from "./event_center_browser";
import { BrowserEventTypes, global } from "./app_browser";


export class ProducerHistoryRoute extends Producer {
    enable(): boolean {
        return true;
    }
    init(): void {
        const _self = this;
        let lastHref: string
        if (!supportsHistory()) {
            return;
        }
        const oldOnpopstate = global.onpopstate;
        global.onpopstate = function (this: WindowEventHandlers, ...args: any[]): any {
            const to = getLocationHref();
            const from = lastHref;
            lastHref = to;

            _self.produce({
                from,
                to
            });

            oldOnpopstate && oldOnpopstate.apply(this, args)
        }
        function historyReplaceFn(originalHistoryFn: voidFun): voidFun {
            return function (this: History, ...args: any[]): void {
                const url = args.length > 2 ? args[2] : undefined
                if (url) {
                    const from = lastHref;
                    const to = String(url);
                    lastHref = to;
                    _self.produce({
                        from,
                        to
                    });
                }
                return originalHistoryFn.apply(this, args)
            }
        }

        replaceOld(global.history, 'pushState', historyReplaceFn);
        replaceOld(global.history, 'replaceState', historyReplaceFn);

        console.info(`producer history Route init done`);
    }
    produce(args: any): void {
        EventCenterBrowser.getInstance().dispatch(BrowserEventTypes.HISTORY, args);
        return args;
    }

}


export function supportsHistory(): boolean {
    // borrowed from: https://github.com/angular/angular.js/pull/13945/files
    const chrome = (global as any).chrome
    const isChromePackagedApp = chrome && chrome.app && chrome.app.runtime
    const hasHistoryApi = 'history' in global && !!global.history.pushState && !!global.history.replaceState
    return !isChromePackagedApp && hasHistoryApi
}


