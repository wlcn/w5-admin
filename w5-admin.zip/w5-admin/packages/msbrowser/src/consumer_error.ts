import { ErrorTypes, getLocationHref, getTimestamp, interceptStr } from "./common";
import { EventCenterBrowser } from "./event_center_browser";
import { BrowserEventTypes } from "./app_browser";
import { Consumer } from "mscore";

export class ConsumerError extends Consumer {
    enable(): boolean {
        return true;
    }
    init(): void {
        EventCenterBrowser.getInstance().on(BrowserEventTypes.ERROR, (event: any) => {
            this.consume(event);
        });
    }
    consume(event: any): void {
        const key = event.eventName + getTimestamp();
        const target = event.data.target as ResourceErrorTarget
        let data;
        if (target.localName) {
            // resource error
            data = resourceTransform(event.data.target as ResourceErrorTarget);
        }
        // code error
        data = codeErrorTransform(event.data);

        localStorage.setItem(key, JSON.stringify(data));
    }

}

export interface ResourceErrorTarget {
    src?: string
    href?: string
    localName?: string
}


function resourceTransform(target: ResourceErrorTarget) {
    return {
        type: ErrorTypes.RESOURCE,
        url: getLocationHref(),
        message: 'URI: ' + (interceptStr(target.src as any, 120) || interceptStr(target.href as any, 120)),
        time: getTimestamp(),
        name: `${target.localName} load failed`
    }
}

function codeErrorTransform(errorEvent: ErrorEvent) {
    const { message, filename, lineno, colno, error } = errorEvent
    const result = handleNotErrorInstance(message, filename, lineno, colno) as any;
    result.type = ErrorTypes.JAVASCRIPT;
    return result
}

export const ERROR_TYPE_RE = /^(?:[Uu]ncaught (?:exception: )?)?(?:((?:Eval|Internal|Range|Reference|Syntax|Type|URI|)Error): )?(.*)$/

function handleNotErrorInstance(message: string, filename: string, lineno: number, colno: number) {
    let name: string | ErrorTypes = ErrorTypes.UNKNOWN
    const url = filename || getLocationHref()
    let msg = message
    const matches = message.match(ERROR_TYPE_RE) as any;
    if (matches[1]) {
        name = matches[1]
        msg = matches[2]
    }
    const element = {
        url,
        func: ErrorTypes.UNKNOWN_FUNCTION,
        args: ErrorTypes.UNKNOWN,
        line: lineno,
        col: colno
    }
    return {
        url,
        name,
        message: msg,
        time: getTimestamp(),
        stack: [element]
    }
}