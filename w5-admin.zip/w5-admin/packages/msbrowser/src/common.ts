import { global } from "./app_browser"
import { beacon, get, imgRequest, post } from "./request"

export function replaceOld(source: any, name: string, replacement: (...args: any[]) => any, isForced = false): void {
    if (source === undefined) return
    if (name in source || isForced) {
        const original = source[name]
        const wrapped = replacement(original)
        if (typeof wrapped === 'function') {
            source[name] = wrapped
        }
    }
}

export type voidFun = () => void

export interface IAnyObject {
    [key: string]: any
}

type TotalEventName = keyof GlobalEventHandlersEventMap | keyof XMLHttpRequestEventTargetEventMap | keyof WindowEventMap

export function on(
    target: { addEventListener: Function },
    eventName: TotalEventName,
    handler: Function,
    opitons: boolean | unknown = false
): void {
    target.addEventListener(eventName, handler, opitons)
}

export function throttle(fn: Function, delay: number): Function {
    let canRun = true;
    return function (...args: any) {
        if (!canRun) return;
        fn.apply(this, args);
        canRun = false;
        setTimeout(() => {
            canRun = true;
        }, delay);
    };
}

export function getTimestamp(): number {
    return Date.now()
}

export const enum ToStringTypes {
    String = 'String',
    Number = 'Number',
    Boolean = 'Boolean',
    RegExp = 'RegExp',
    Null = 'Null',
    Undefined = 'Undefined',
    Symbol = 'Symbol',
    Object = 'Object',
    Array = 'Array',
    process = 'process',
    Window = 'Window',
    Function = 'Function'
}

export const nativeToString = Object.prototype.toString

export function isType(type: string) {
    return function (value: any): boolean {
        return nativeToString.call(value) === `[object ${type}]`
    }
}

export function unknownToString(target: unknown): string {
    if (variableTypeDetection.isString(target)) {
        return target as string
    }
    if (variableTypeDetection.isUndefined(target)) {
        return 'undefined'
    }
    return JSON.stringify(target)
}

export const variableTypeDetection = {
    isNumber: isType(ToStringTypes.Number),
    isString: isType(ToStringTypes.String),
    isBoolean: isType(ToStringTypes.Boolean),
    isNull: isType(ToStringTypes.Null),
    isUndefined: isType(ToStringTypes.Undefined),
    isSymbol: isType(ToStringTypes.Symbol),
    isFunction: isType(ToStringTypes.Function),
    isObject: isType(ToStringTypes.Object),
    isArray: isType(ToStringTypes.Array),
    isProcess: isType(ToStringTypes.process),
    isWindow: isType(ToStringTypes.Window)
}

export interface MSXMLHttpRequest extends XMLHttpRequest {
    [key: string]: any
    httpCollect?: HttpCollectedType
}

export interface HttpCollectedType {
    headers?: Headers,
    request: {
        httpType?: HttpTypes
        traceId?: string
        method?: string
        url?: string
        data?: any
    }
    response: {
        status?: number
        data?: any
    }
    // for wx
    errMsg?: string
    elapsedTime?: number
    time?: number
}

export const enum HttpTypes {
    XHR = 'xhr',
    FETCH = 'fetch'
}

export const getUrlPath = (url: string): string => {
    const path = `${(url || '').replace(/^http(s|):/, '').split('?')[0]}`;
    const endIndex = path.length - 1;
    return path[endIndex] === '/' ? path.substring(0, endIndex) : path;
};

export function obj2query(data: IAnyObject): string {
    return Object.keys(data).reduce((pre, cur) => {
        const val = data[cur];
        pre += `${pre ? '&' : ''}${cur}=${typeof val === 'object' ? JSON.stringify(val) : val}`;
        return pre;
    }, '');
}


export enum BrowserReportType {
    BEACON = 'beacon',
    IMG = 'img',
    GET = 'get',
    POST = 'post'
}

export enum MethodTypes {
    GET = 'GET',
    POST = 'POST',
    PUT = 'PUT',
    DELETE = 'DELETE'
}

export function report(url: string, data: IAnyObject, type: BrowserReportType = BrowserReportType.BEACON) {
    if (type === BrowserReportType.BEACON) {
        beacon(url, data);
        return;
    }
    if (type === BrowserReportType.IMG || !navigator.sendBeacon) {
        imgRequest(url, data);
        return;
    }
    if (type === BrowserReportType.POST) {
        post(url, data);
        return;
    }
    return get(url, data);
}

export function getLocationHref(): string {
    if (typeof document === 'undefined' || document.location == null) return ''
    return document.location.href
}

export function interceptStr(str: string, interceptLength: number): string {
    if (variableTypeDetection.isString(str)) {
        return str.slice(0, interceptLength) + (str.length > interceptLength ? `;slice the first ${interceptLength} characters` : '')
    }
    return ''
}

export const enum ErrorTypes {
    UNKNOWN = 'UNKNOWN',
    UNKNOWN_FUNCTION = 'UNKNOWN_FUNCTION',
    JAVASCRIPT = 'JAVASCRIPT',
    LOG = 'LOG',
    HTTP = 'HTTP',
    VUE = 'VUE',
    REACT = 'REACT',
    RESOURCE = 'RESOURCE',
    PROMISE = 'PROMISE',
    ROUTE = 'ROUTE'
}

export function getTrackerId(): string | number {
    const backTrackerId = global.browserOptions.backTrackerId;
    if (typeof backTrackerId === 'function') {
        const trackerId = backTrackerId()
        if (typeof trackerId === 'string' || typeof trackerId === 'number') {
            return trackerId
        } else {
            console.error(`trackerId:${trackerId} expected string or number, but ${typeof trackerId}`)
        }
    }
    return ''
}
