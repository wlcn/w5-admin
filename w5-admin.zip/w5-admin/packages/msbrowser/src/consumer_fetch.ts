import { getTimestamp, report } from "./common";
import { EventCenterBrowser } from "./event_center_browser";
import { BrowserEventTypes, global } from "./app_browser";
import { Consumer } from "mscore";

export class ConsumerFetch extends Consumer {

    enable(): boolean {
        return true;
    }
    init(): void {
        EventCenterBrowser.getInstance().on(BrowserEventTypes.FETCH, (event: any) => {
            this.consume(event);
        });
    }
    consume(event: any): void {
        const { dsn } = global.browserOptions;
        const key = event.eventName + getTimestamp();
        localStorage.setItem(key, JSON.stringify(event.data));
        report(dsn, event.data);
    }

}