import { getTimestamp } from "./common";
import { EventCenterBrowser } from "./event_center_browser";
import { BrowserEventTypes } from "./app_browser";
import { Consumer } from "mscore";

export class ConsumerHashRoute extends Consumer {
    enable(): boolean {
        return true;
    }
    init(): void {
        EventCenterBrowser.getInstance().on(BrowserEventTypes.HASHCHANGE, (event: any) => {
            this.consume(event);
        });
    }
    consume(event: any): void {
        const key = event.eventName + getTimestamp();
        localStorage.setItem(key, JSON.stringify(event.data));
    }

}