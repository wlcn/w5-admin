import { Producer } from "mscore";
import { on } from "./common";
import { EventCenterBrowser } from "./event_center_browser";
import { BrowserEventTypes, global } from "./app_browser";


export class ProducerHashRoute extends Producer {
    enable(): boolean {
        return true;
    }
    init(): void {
        const _self = this;
        if (!isExistProperty(global, 'onpopstate')) {
            on(global, BrowserEventTypes.HASHCHANGE, function (e: HashChangeEvent) {
                const { oldURL: from, newURL: to } = e
                _self.produce({ from, to })
            })
        }
        console.info(`producer hashRoute init done`);
    }
    produce(args: any): void {
        EventCenterBrowser.getInstance().dispatch(BrowserEventTypes.HASHCHANGE, args);
        return args;
    }

}

export function isExistProperty(obj: Object, key: string | number | symbol): boolean {
    return Object.prototype.hasOwnProperty.call(obj, key)
}


