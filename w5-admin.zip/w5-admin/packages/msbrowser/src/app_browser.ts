import { App } from 'mscore';
import { ConsumerConsole } from './consumer_console';
import { ProducerConsole } from './producer_console';
import { ProducerError } from './producer_error';
import { ConsumerError } from './consumer_error';
import { ConsumerDom } from './consumer_dom';
import { ProducerDom } from './producer_dom';
import { ProducerPromise } from './producer_promise';
import { ConsumerPromise } from './consumer_promise';
import { ConsumerHashRoute } from './consumer_hash_route';
import { ProducerHashRoute } from './producer_hash_route';
import { ConsumerHistoryRoute } from './consumer_history_route';
import { ProducerHistoryRoute } from './producer_history_route';
import { ConsumerXhr } from './consumer_xhr';
import { ProducerXhr } from './producer_xhr';
import { ConsumerFetch } from './consumer_fetch';
import { ProducerFetch } from './producer_fetch';


export const enum BrowserEventTypes {
    XHR = 'xhr',
    FETCH = 'fetch',
    CONSOLE = 'console',
    DOM = 'dom',
    HISTORY = 'history',
    ERROR = 'error',
    HASHCHANGE = 'hashchange',
    UNHANDLEDREJECTION = 'unhandledrejection',
    CUSTOMER = 'Customer'
}

export enum BrowserBreadcrumbTypes {
    ROUTE = 'Route',
    CLICK = 'UI.Click',
    CONSOLE = 'Console',
    XHR = 'Xhr',
    FETCH = 'Fetch',
    UNHANDLEDREJECTION = 'Unhandledrejection',
    RESOURCE = 'Resource',
    CODE_ERROR = 'CodeError',
    CUSTOMER = 'Customer',
    FRAMEWORK = 'Framework',
    LIFECYCLE = 'LifeCycle',
    CRASH = 'Crash'
}

export interface BrowserOptions {
    app?: string;
    env?: string;
    dsn: string;
    enableConsole?: boolean;
    enableError?: boolean;
    enableDom?: boolean;
    enableFetch?: boolean;
    enableXhr?: boolean;
    enableHashRoute?: boolean;
    enableHistoryRoute?: boolean;
    enablePromise?: boolean;
    throttleDelayTime?: number;
    ignoreUrls?: string[],
    reportResponds?: boolean;
    backTrackerId?: Function;
}

export const global: any = window;

export class BrowserApp extends App {

    init({
        dsn = '',
        app = '',
        env = '',
        enableConsole = false,
        enableError = true,
        enableDom = false,
        enableFetch = true,
        enableXhr = true,
        enableHashRoute = true,
        enableHistoryRoute = true,
        enablePromise = true,
        throttleDelayTime = 500,
        ignoreUrls = [],
        reportResponds = true,
        backTrackerId,
    }: BrowserOptions = { dsn: '' }): void {
        if (!dsn) {
            console.error('dsn is required.');
            return;
        }
        global.browserOptions = {
            app,
            env,
            dsn,
            enableConsole,
            enableError,
            enableDom,
            enableFetch,
            enableXhr,
            enableHashRoute,
            enableHistoryRoute,
            enablePromise,
            throttleDelayTime,
            ignoreUrls,
            reportResponds,
            backTrackerId,
        };
        const browserOptions = global.browserOptions;
        if (!browserOptions) {
            console.error(`please provide browserOptions`);
        }
        if (browserOptions?.enableConsole) {
            this.consumerList.push(new ConsumerConsole());
            this.producerList.push(new ProducerConsole());
        }

        if (browserOptions?.enableError) {
            this.consumerList.push(new ConsumerError);
            this.producerList.push(new ProducerError);
        }

        if (browserOptions?.enableDom) {
            this.consumerList.push(new ConsumerDom());
            this.producerList.push(new ProducerDom());
        }

        if (browserOptions?.enablePromise) {
            this.consumerList.push(new ConsumerPromise());
            this.producerList.push(new ProducerPromise());
        }
        if (browserOptions?.enableHashRoute) {
            this.consumerList.push(new ConsumerHashRoute());
            this.producerList.push(new ProducerHashRoute());
        }
        if (browserOptions?.enableHistoryRoute) {
            this.consumerList.push(new ConsumerHistoryRoute());
            this.producerList.push(new ProducerHistoryRoute());
        }
        if (browserOptions?.enableXhr) {
            this.consumerList.push(new ConsumerXhr());
            this.producerList.push(new ProducerXhr());
        }
        if (browserOptions?.enableFetch) {
            this.consumerList.push(new ConsumerFetch());
            this.producerList.push(new ProducerFetch());
        }

        console.info(`browser app init `);
    }
}


global.BrowserApp = BrowserApp;
