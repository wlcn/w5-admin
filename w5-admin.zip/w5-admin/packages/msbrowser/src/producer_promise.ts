import { Producer } from "mscore";
import { on } from "./common";
import { EventCenterBrowser } from "./event_center_browser";
import { BrowserEventTypes, global } from "./app_browser";


export class ProducerPromise extends Producer {
    enable(): boolean {
        return true;
    }
    init(): void {
        const _self = this;
        on(global, BrowserEventTypes.UNHANDLEDREJECTION, function (ev: PromiseRejectionEvent) {
            _self.produce(ev);
        })
        console.info(`producer promise init done`);
    }
    produce(args: any): void {
        EventCenterBrowser.getInstance().dispatch(BrowserEventTypes.UNHANDLEDREJECTION, args);
        return args;
    }

}


