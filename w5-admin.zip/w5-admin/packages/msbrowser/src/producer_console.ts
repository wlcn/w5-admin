import { Producer } from "mscore";
import { replaceOld } from "./common";
import { EventCenterBrowser } from "./event_center_browser";
import { BrowserEventTypes } from "./app_browser";

export interface ConsoleItem {
    level: string;
    args: any;
}

export class ProducerConsole extends Producer {
    enable(): boolean {
        return true;
    }
    init(): void {
        const logTypeArr = ['log', 'debug', 'info', 'warn', 'error', 'assert']
        const _self = this;
        logTypeArr.forEach(function (level: string): void {
            if (!(level in console)) return
            replaceOld(console, level, function (originalConsole: () => any): Function {
                return function (...args: any): void {
                    if (originalConsole) {

                        const consoleItem = { level, args };
                        _self.produce(consoleItem);

                        originalConsole.apply(console, args)
                    }
                }
            })
        });
        console.info(`producer console init done`);
    }
    produce(args: any): void {
        EventCenterBrowser.getInstance().dispatch(BrowserEventTypes.CONSOLE, args);
        return args;
    }

}