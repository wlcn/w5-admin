export abstract class Consumer {

    abstract enable(): boolean;

    abstract init(): void;

    abstract consume(event: any): void;

}