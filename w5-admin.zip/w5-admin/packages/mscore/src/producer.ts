export abstract class Producer {

    abstract enable(): boolean;

    abstract init(): void;

    abstract produce(args: any): void;

}