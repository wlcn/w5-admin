import { Consumer } from "./consumer";
import { Producer } from "./producer";

export abstract class App {

    protected producerList: Producer[] = [];
    protected consumerList: Consumer[] = [];


    abstract init(options: any): void;

    start(): void {
        const producerListLength = this.producerList.length;
        if (producerListLength === 0) {
            console.error('producer list size is 0');
            return;
        }
        const consumerListLength = this.consumerList.length;
        if (consumerListLength === 0) {
            console.error('consumer list size is 0');
            return;
        }
        this.producerList.forEach(p => p.init());
        console.info(`init ${producerListLength} producers done`);
        this.consumerList.forEach(c => c.init());
        console.info(`init ${consumerListLength} consumers done`);
    }


}



