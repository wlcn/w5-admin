export class EventData {
    eventName: string;
    data: any;
    constructor(eventName: string, data: any) {
        this.eventName = eventName;
        this.data = data;
    }
}

export abstract class EventCenter {

    abstract on(eventName: string, callback: any): void;

    abstract off(eventName: string, callback: any): void;

    abstract dispatch(eventName: string, data: any): void;
}